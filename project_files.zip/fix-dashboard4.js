import fs from "fs";

let code = fs.readFileSync("src/routes/dashboard.tsx", "utf8");

// The easiest way is to just carefully remove the trailing </div></CardHeader> and replace it with </CardHeader> if there was no <div className="flex items-center gap-2"> before it.
// Actually, let's just use regex to fix the exact lines.

code = code.replace(
  /<\/span><\/CardTitle><\/div><\/CardHeader>/g,
  "</span></CardTitle></CardHeader>",
);

code = code.replace(
  /<CardTitle className="text-base">\{title\}<\/CardTitle><\/div><\/CardHeader>/g,
  '<CardTitle className="text-base">{title}</CardTitle></CardHeader>',
);

code = code.replace(
  /<CardTitle className="flex items-center gap-2">\s*<Sparkles className="h-5 w-5 text-accent" \/>\s*محرك التنبيهات\s*<\/CardTitle><\/div><\/CardHeader>/g,
  '<CardTitle className="flex items-center gap-2"><Sparkles className="h-5 w-5 text-accent" />محرك التنبيهات</CardTitle></CardHeader>',
);

code = code.replace(
  /<CardTitle className="flex items-center gap-2 text-base sm:text-lg font-extrabold">\s*<History className="h-5 w-5 text-accent" \/>\s*مقارنة زمنية\s*<\/CardTitle><\/div><\/CardHeader>/g,
  '<CardTitle className="flex items-center gap-2 text-base sm:text-lg font-extrabold"><History className="h-5 w-5 text-accent" />مقارنة زمنية</CardTitle></CardHeader>',
);

// Specifically for the product details card:
code = code.replace(
  /<List className="h-5 w-5 text-emerald-500 shrink-0" \/>\s*<\/span>\s*<\/CardTitle>\s*<\/div>\s*<\/CardHeader>/g,
  '<List className="h-5 w-5 text-emerald-500 shrink-0" /></span></CardTitle></CardHeader>',
);

// I'll also just check for any remaining `</CardTitle></div></CardHeader>` and ensure they all have a matching `<div className="flex items-center gap-2">` at the start.
fs.writeFileSync("src/routes/dashboard.tsx", code);
