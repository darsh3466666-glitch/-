import fs from "fs";

let code = fs.readFileSync("src/routes/dashboard.tsx", "utf8");

code = code.replace(
  /<div className="flex items-center gap-2"><span className="text-2xl">📈<\/span><CardTitle className="text-xl font-extrabold flex items-center justify-between w-full text-primary-dark">/g,
  '<CardTitle className="text-xl font-extrabold flex items-center justify-between w-full text-primary-dark"><span className="flex items-center gap-2"><span className="text-2xl">📈</span>',
);

code = code.replace(
  /<\/span><\/CardTitle><\/CardHeader>/g,
  "</span></span></CardTitle></CardHeader>",
);

fs.writeFileSync("src/routes/dashboard.tsx", code);
