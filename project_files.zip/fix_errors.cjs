const fs = require('fs');

// Fix 1: GoogleDrivePicker
let gPicker = fs.readFileSync('src/components/dashboard/GoogleDrivePicker.tsx', 'utf-8');
gPicker = gPicker.replace(`(_user, t) => {`, `(_user: any, t: string) => {`);
fs.writeFileSync('src/components/dashboard/GoogleDrivePicker.tsx', gPicker);

// Fix 2: history.tsx
let hist = fs.readFileSync('src/routes/history.tsx', 'utf-8');
hist = `import React from 'react';\n` + hist;
fs.writeFileSync('src/routes/history.tsx', hist);

