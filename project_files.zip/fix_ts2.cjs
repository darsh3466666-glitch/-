const fs = require('fs');
let lib = fs.readFileSync('src/lib/excel-parser.functions.ts', 'utf-8');

lib = lib.replace(/let prevBalance = sabeqBalances\.get\(normName\);\s*if \(prevBalance === undefined\) prevBalance = fromSales\?\.prev_balance \?\? 0;/g, 
  'const prevBalance = sabeqBalances.get(normName) ?? fromSales?.prev_balance ?? 0;');

fs.writeFileSync('src/lib/excel-parser.functions.ts', lib);

// Fix dashboard.tsx
let route = fs.readFileSync('src/routes/dashboard.tsx', 'utf-8');
route = route.replace(/risk_score: risk,([\s\S]*?)status: status,([\s\S]*?)prev_balance: 0,\}/g, 'risk_score: risk,$1status: status,$2prev_balance: 0,}'); // actually I already replaced it, let's see why it failed.
fs.writeFileSync('src/routes/dashboard.tsx', route);

