const PRODUCT_ORDER = [
  "ذرة صفراء",
  "نخالة",
  "كسب",
  "فول صويا ٤٤٪",
  "دي دي جي إس",
  "فول صويا ٤٦٪",
  "رجيع كون",
  "جلوتوفيد",
  "علف النور تسمين",
  "علف النور حلاب",
  "كربونات البوتاسيوم",
  "بريمكس تسمين",
  "أملاح معدنية حلاب",
  "فيتامينات حلاب",
  "حجر جيري",
  "ثنائي فوسفات الكالسيوم",
  "أحادي فوسفات الكالسيوم",
  "ملح طعام",
  "مضاد سموم بيولوجي",
  "مضاد سموم كيميائي",
  "خميرة",
  "أكسيد الماغنسيوم",
  "بيكربونات الصوديوم",
  "م. التصنيع",
  "م. العمال",
  "م. النقل",
];

function normalizeProductName(name) {
  return name
    .replace(/أ/g, "ا")
    .replace(/إ/g, "ا")
    .replace(/آ/g, "ا")
    .replace(/ة/g, "ه")
    .replace(/ى/g, "ي")
    .replace(/4/g, "٤")
    .replace(/6/g, "٦")
    .replace(/%/g, "٪")
    .replace(/تصنيع/g, "م. التصنيع")
    .replace(/عمال/g, "م. العمال")
    .replace(/نقل/g, "م. النقل")
    .replace(/م\.\s*م\.\s*/g, "م. ")
    .replace(/م\.\s*التصنيع/g, "م. التصنيع")
    .replace(/م\.\s*العمال/g, "م. العمال")
    .replace(/م\.\s*النقل/g, "م. النقل")
    .replace(/رجيعة\s*كون/g, "رجيع كون")
    .replace(/رجيعة/g, "رجيع كون")
    .replace(/دي\s*دي\s*جي\s*إس/g, "دي دي جي إس")
    .replace(/دي\s*دي\s*جي/g, "دي دي جي إس")
    .trim();
}

const NORMALIZED_ORDER = PRODUCT_ORDER.map(normalizeProductName);

function getProductSortIndex(productName) {
  const normalized = normalizeProductName(productName);

  let index = NORMALIZED_ORDER.indexOf(normalized);
  if (index !== -1) return index;

  for (let i = 0; i < NORMALIZED_ORDER.length; i++) {
    if (
      normalized.includes(NORMALIZED_ORDER[i]) ||
      NORMALIZED_ORDER[i].includes(normalized)
    ) {
      return i;
    }
  }

  return 999;
}

const input = [
  "ذره صفراء",
  "نخاله",
  "بريمكس تسمين",
  "حجر جيرى",
  "ملح طعام",
  "خميره",
  "تصنيع",
  "عمال",
  "اكسيد ماغنسيوم",
  "بيكربونات صوديوم",
  "فول صويا46%",
  "مضاد سموم كيميائي",
];

console.log("Normalized array: ", NORMALIZED_ORDER);
input.forEach((n) => console.log(n, "->", getProductSortIndex(n)));
