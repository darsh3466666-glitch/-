const PRODUCT_ORDER = [
  "ذرة صفراء",
  "نخالة",
  "كسب",
  "فول صويا ٤٤٪",
  "دي دي جي إس",
  "فول صويا ٤٦٪",
  "رجيع كون",
  "جلوتوفيد",
  "علف النور تسمين",
  "علف النور حلاب",
  "كربونات البوتاسيوم",
  "بريمكس تسمين",
  "أملاح معدنية حلاب",
  "فيتامينات حلاب",
  "حجر جيري",
  "ثنائي فوسفات الكالسيوم",
  "أحادي فوسفات الكالسيوم",
  "ملح طعام",
  "مضاد سموم بيولوجي",
  "مضاد سموم كيميائي",
  "خميرة",
  "أكسيد الماغنسيوم",
  "بيكربونات الصوديوم",
  "م. التصنيع",
  "م. العمال",
  "م. النقل",
];

function normalizeProductName(name) {
  let s = name
    .replace(/أ/g, "ا")
    .replace(/إ/g, "ا")
    .replace(/آ/g, "ا")
    .replace(/ة/g, "ه")
    .replace(/ى/g, "ي")
    .replace(/4/g, "٤")
    .replace(/6/g, "٦")
    .replace(/%/g, "٪")
    .replace(/ال/g, "") // remove 'ال'
    .replace(/م\./g, "") // remove 'م.'
    .replace(/\s+/g, "") // remove all spaces
    .trim();

  if (s === "ديديجي") s = "ديديجياس";
  if (s.includes("رجيع")) s = "رجيعكون";

  return s;
}

const NORMALIZED_ORDER = PRODUCT_ORDER.map(normalizeProductName);

function getProductSortIndex(productName) {
  const normalized = normalizeProductName(productName);

  let index = NORMALIZED_ORDER.indexOf(normalized);
  if (index !== -1) return index;

  for (let i = 0; i < NORMALIZED_ORDER.length; i++) {
    if (
      normalized.includes(NORMALIZED_ORDER[i]) ||
      NORMALIZED_ORDER[i].includes(normalized)
    ) {
      return i;
    }
  }

  return 999;
}

const input = [
  "ذره صفراء",
  "نخاله",
  "بريمكس تسمين",
  "حجر جيرى",
  "ملح طعام",
  "خميره",
  "تصنيع",
  "عمال",
  "اكسيد ماغنسيوم",
  "بيكربونات صوديوم",
  "فول صويا46%",
  "مضاد سموم كيميائي",
  "دي دي جي",
  "رجيعة",
];

console.log("Normalized array: ", NORMALIZED_ORDER);
input.forEach((n) => console.log(n, "->", getProductSortIndex(n)));
