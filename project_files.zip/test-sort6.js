import { getProductSortIndex } from "./src/lib/product-sorting.js";
// Actually, I can't import .ts file in vanilla Node easily.
