function normalizeProductName(name) {
  let s = name
    .replace(/أ/g, "ا")
    .replace(/إ/g, "ا")
    .replace(/آ/g, "ا")
    .replace(/ة/g, "ه")
    .replace(/ى/g, "ي")
    .replace(/4/g, "٤")
    .replace(/6/g, "٦")
    .replace(/%/g, "٪")
    .replace(/م\./g, "");

  // remove all whitespace and invisible chars, keep only Arabic letters, numbers, and %
  s = s.replace(/[^\u0621-\u064A0-9٤٦٪]/g, "");

  // Also remove 'ال' if it starts with it
  if (s.startsWith("ال")) s = s.substring(2);

  if (s === "ديديجي") s = "ديديجياس";
  if (s.includes("رجيع")) s = "رجيعكون";

  return s;
}

console.log(normalizeProductName("فول صويا ٤٦٪"));
console.log(normalizeProductName("\u200Fفول صويا46%"));
