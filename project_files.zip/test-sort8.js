const PRODUCT_ORDER = [
  "ذرة صفراء",
  "نخالة",
  "كسب",
  "فول صويا ٤٤٪",
  "دي دي جي إس",
  "فول صويا ٤٦٪",
  "رجيع كون",
  "جلوتوفيد",
  "علف النور تسمين",
  "علف النور حلاب",
  "كربونات البوتاسيوم",
  "بريمكس تسمين",
  "أملاح معدنية حلاب",
  "فيتامينات حلاب",
  "حجر جيري",
  "ثنائي فوسفات الكالسيوم",
  "أحادي فوسفات الكالسيوم",
  "ملح طعام",
  "مضاد سموم بيولوجي",
  "مضاد سموم كيميائي",
  "خميرة",
  "أكسيد الماغنسيوم",
  "بيكربونات الصوديوم",
  "م. التصنيع",
  "م. العمال",
  "م. النقل",
];

function normalizeProductName(name) {
  let s = name
    .replace(/أ/g, "ا")
    .replace(/إ/g, "ا")
    .replace(/آ/g, "ا")
    .replace(/ة/g, "ه")
    .replace(/ى/g, "ي")
    .replace(/4/g, "٤")
    .replace(/6/g, "٦")
    .replace(/%/g, "٪");

  // Remove "ال" and "م." from words before crushing
  s = s
    .split(/\s+/)
    .map((w) => {
      let word = w.replace(/^م\./, "");
      if (word.startsWith("ال")) word = word.substring(2);
      return word;
    })
    .join("");

  // Now crush all invisible characters, punctuation, etc.
  s = s.replace(/[^\u0621-\u064A0-9٤٦٪a-zA-Z]/g, "");

  if (s === "ديديجي") s = "ديديجياس";
  if (s.includes("رجيع")) s = "رجيعكون";

  return s;
}

console.log(PRODUCT_ORDER.map(normalizeProductName));
